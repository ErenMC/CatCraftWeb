<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CatCraft</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/mem.css">
</head>
<body>
    <!-- Меню панель -->
    <nav>
        <div class="menu-right">
            <img src="img/logo2.png" alt="Лого сервера" class="logo">
            <a href="https://example.com"><img src="img/button1.png" alt="Кнопка 1"></a>
            <a href="https://example.com"><img src="img/button2.png" alt="Кнопка 2"></a>
            <a href="https://example.com"><img src="img/button3.png" alt="Кнопка 3"></a>
        </div>
        <div class="menu-left">
            <button id="login-button" class="hidden" onclick="authorizeDiscord()">Зайти</button>
            <div id="user-info" class="hidden">
                <img id="avatar" class="avatar" alt="Аватар">
                <div id="user-menu" class="user-menu hidden">
                    <p id="discord-name">Discord: Неизвестно</p>
                    <p id="minecraft-name">Minecraft: Неизвестно</p>
                    <p id="balance">Баланс: 0</p>
                    <hr>
                    <button onclick="gotoSocialNetwork()">Зайти на соц сеть</button>
                    <button onclick="logout()">Выйти</button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Основная информация -->
    <section class="main-info">
        <div class="info-image">
            <img src="img/sleepy_cat.png" alt="Изображение сервера">
        </div>
        <div class="info-text">
            <h1>Лучший. Кошачий. Навсегда!</h1>
            <p>Кошкокрафт - это приватный Ванилла+
                сервер с элементами Role-play и котиками!</p>
        </div>
    </section>

    <svg class="editorial"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    viewBox="0 24 150 28 "
    preserveAspectRatio="none">
<defs>
<path id="gentle-wave"
d="M-160 44c30 0 
   58-18 88-18s
   58 18 88 18 
   58-18 88-18 
   58 18 88 18
   v44h-352z" />
</defs>
<g class="parallax1">
 <use xlink:href="#gentle-wave" x="50" y="3" fill="#804FEB"/>
</g>
  <g class="parallax2">
 <use xlink:href="#gentle-wave" x="50" y="0" fill="#6E42DA"/>
  </g>
    <g class="parallax3">
 <use xlink:href="#gentle-wave" x="50" y="9" fill="#5C36C9"/>
 </g>
  <g class="parallax4">
 <use xlink:href="#gentle-wave" x="50" y="6" fill="#1E1E1E"/>  
</g>
</svg>

    <!-- Скриншоты -->
    <section class="screenshots">
        <div class="screenshot" id="screenshot1"></div>
        <div class="screenshot" id="screenshot2"></div>
        <div class="screenshot" id="screenshot3"></div>
    </section>

    <!-- Футер -->
    <footer>
        <div class="footer-left">
            <p>Лучший. Кошачий. Навсегда!</p>
        </div>
        <div class="footer-center">
            <img src="img/logo2.png" alt="Лого 2" class="footer-logo">
        </div>
        <div class="footer-right">
            <button class="footer-button"></button>
            <button class="footer-button"></button>
            <button class="footer-button"></button>
            <button class="footer-button"></button>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script src="js/auth.js"></script>

    </body>
</html>

// Функция для авторизации через Discord
function authorizeDiscord() {
    fetch('config.json')
        .then(response => response.json())
        .then(config => {
            const clientId = config.discord.clientId;
            const redirectUri = encodeURIComponent(config.discord.redirectUri);
            const scope = encodeURIComponent('identify email');
            const discordAuthUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}`;
            window.location.href = discordAuthUrl;
        })
        .catch(error => {
            console.error('Ошибка при загрузке конфигурационного файла:', error);
        });
}

// Функция для получения информации о пользователе из cookies
function loadUserInfo() {
    const cookies = document.cookie.split('; ');
    let sessionToken = null;
    cookies.forEach(cookie => {
        const [name, value] = cookie.split('=');
        if (name === 'session_token') {
            sessionToken = value;
        }
    });

    if (sessionToken) {
        fetch('get_user_info.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ session_token: sessionToken })
        })
        .then(response => response.json())
        .then(user => {
            if (user) {
                updateUserInfo(user);
            } else {
                document.getElementById('login-button').classList.remove('hidden');
            }
        })
        .catch(error => {
            console.error('Ошибка при получении информации о пользователе:', error);
            document.getElementById('login-button').classList.remove('hidden');
        });
    } else {
        document.getElementById('login-button').classList.remove('hidden');
    }
}

// Функция для обновления информации о пользователе на странице
function updateUserInfo(user) {
    document.getElementById('login-button').classList.add('hidden'); 
    const userInfo = document.getElementById('user-info');
    userInfo.classList.remove('hidden'); 
    document.getElementById('avatar').src = user.avatar; 
    document.getElementById('discord-name').textContent = `Discord: ${user.discordName}`; 
    document.getElementById('minecraft-name').textContent = `Minecraft: ${user.minecraftName}`; 
    document.getElementById('balance').textContent = `Баланс: ${user.balance}`; 

    document.getElementById('avatar').addEventListener('click', () => {
        const userMenu = document.getElementById('user-menu');
        userMenu.classList.toggle('hidden');
    });
}

// Функция для перехода на социальную сеть
function gotoSocialNetwork() {
    window.location.href = 'https://example.com/social-network';
}

// Функция для выхода пользователя
function logout() {
    document.cookie = 'session_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    location.reload();
}

// Вызываем функцию загрузки информации о пользователе при загрузке страницы
window.onload = function() {
    loadUserInfo();
};

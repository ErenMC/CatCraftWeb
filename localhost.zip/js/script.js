// Функция для загрузки случайных скриншотов
function loadScreenshots() {
    const screenshotContainer = document.querySelectorAll('.screenshot');
    const screenshotsPath = 'img/slrin/';

    // Пример имен файлов скриншотов (обычно это будет загружено с сервера)
    const screenshots = [
        'screenshot1.png',
        'screenshot2.jpg',
        'screenshot3.gif',
        'screenshot4.png'
    ];

    // Выбираем три случайных изображения
    const randomScreenshots = [];
    while (randomScreenshots.length < 3) {
        const randomIndex = Math.floor(Math.random() * screenshots.length);
        if (!randomScreenshots.includes(screenshots[randomIndex])) {
            randomScreenshots.push(screenshots[randomIndex]);
        }
    }

    // Устанавливаем фоны для контейнеров скриншотов
    screenshotContainer.forEach((container, index) => {
        container.style.backgroundImage = `url(${screenshotsPath}${randomScreenshots[index]})`;
    });
}

// Вызываем функцию загрузки скриншотов при загрузке страницы
window.onload = function() {
    loadScreenshots();
};

// Вызываем функцию загрузки скриншотов при загрузке страницы
window.onload = function() {
    loadScreenshots();
};

// Функция для загрузки случайных скриншотов из папки img/slrin
function loadScreenshots() {
    // Допустимые расширения файлов изображений
    const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

    // AJAX-запрос для получения списка файлов в папке img/slrin
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const files = JSON.parse(xhr.responseText);

            // Фильтруем файлы по допустимым расширениям
            const imageFiles = files.filter(file => {
                const extension = file.split('.').pop().toLowerCase();
                return allowedExtensions.includes(extension);
            });

            // Выбираем случайные файлы из списка изображений
            const randomFiles = [];
            for (let i = 0; i < 3; i++) {
                const randomIndex = Math.floor(Math.random() * imageFiles.length);
                randomFiles.push(imageFiles[randomIndex]);
            }

            // Устанавливаем изображения в блоки скриншотов
            for (let i = 0; i < randomFiles.length; i++) {
                const screenshotId = 'screenshot' + (i + 1);
                const screenshotElement = document.getElementById(screenshotId);
                screenshotElement.style.backgroundImage = `url('img/slrin/${randomFiles[i]}')`;
            }
        }
    };
    xhr.open('GET', 'get_image_files.php', true); // Путь к PHP-скрипту для получения файлов
    xhr.send();
}
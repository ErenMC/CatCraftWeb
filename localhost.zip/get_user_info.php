<?php
session_start();
header('Content-Type: application/json');

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Подключение к базе данных
    $conn = new mysqli('localhost', 'root', '', 'catcraft');

    if ($conn->connect_error) {
        die(json_encode(['error' => 'Ошибка подключения к базе данных']));
    }

    // Получение информации о пользователе
    $stmt = $conn->prepare('SELECT discord_id, minecraft_name, balance, avatar FROM users WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($discordId, $minecraftName, $balance, $avatar);
    $stmt->fetch();

    if ($discordId) {
        $user = [
            'discordName' => $discordId,
            'minecraftName' => $minecraftName,
            'balance' => $balance,
            'avatar' => $avatar
        ];
        echo json_encode($user);
    } else {
        echo json_encode(['error' => 'Пользователь не найден']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['error' => 'Пользователь не авторизован']);
}
?>
